import tkinter as tk
from PIL import ImageTk, Image

class Aplikacja:
    def __init__(self,okno):
        self.tekst1 = tk.StringVar()
        self.tekst2 = tk.StringVar()
        self.jezyk = tk.StringVar()
        batonik = tk.StringVar()
        batonik1 = tk.StringVar()
        options = ["warmińsko-mazurskie", "mazowieckie", "pomorskie", "wielkopolskie"]
        selected_option = tk.StringVar(okno)
        selected_option.set(options[0])


        self.label0 = tk.Label(okno, text='Podaj dane: ', background='#76EEC6', font = ('Arial', 12, 'italic'))
        self.label0.grid(row=0, column= 0)

        self.label01 = tk.Label(okno, text='Podaj Imię: ', background='#76EEC6')
        self.label01.grid(row=1, column=0)

        self.entry01 = tk.Entry(okno, textvariable=self.tekst1, font=('Arial',8,'italic'))
        self.entry01.grid(row=1, column=1)

        self.label02 = tk.Label(okno, text='Podaj Nazwisko: ', background='#76EEC6')
        self.label02.grid(row=2,column=0)

        self.entry02 = tk.Entry(okno, textvariable=self.tekst2, font=('Arial',8,'italic'))
        self.entry02.grid(row=2,column=1)

        self.label03 = tk.Label(okno, text='Wybierz język: ', background='#76EEC6')
        self.label03.grid(row=3,column=0)

   
        self.label04 = tk.Checkbutton(okno, text='Python', background='#76EEC6')
        self.label04.grid(row=3, column = 1)
        self.label06 = tk.Checkbutton(okno, text='Java', background = '#76EEC6')
        self.label06.grid(row=3, column= 2)        

        self.label07 = tk.Label(okno, text='Województwo: ', background='#76EEC6')
        self.label07.grid(row=7, column=0)

        self.label08 = tk.OptionMenu(okno,selected_option, *options, )
        self.label08.configure(background='#76FEC6', highlightthickness=0)
        self.label08.grid(row=7, column=1)

        self.label07 = tk.Label(okno, text='Ilość zjedzonych pączków: ', background='#76EEC6')
        self.label07.grid(row=8, column=0)

        self.label10 = tk.Scale(okno, from_=0, to=100, orient=tk.HORIZONTAL, length=100, sliderlength=20, background='#76EEC6')
        self.label10.configure(background='#76EEC6', highlightthickness=0)
        self.label10.grid(row=8, column=1)

        self.label11 = tk.Label(okno, text='Płeć: ', background='#76EEC6')
        self.label11.grid(row=9, column=0)

        self.label12 = tk.Radiobutton(okno,text='mężczyzna' , background='#76EEC6', variable=batonik1)
        self.label12.grid(row=9, column=1)

        self.label13 = tk.Radiobutton(okno,text='Kobieta' , background='#76EEC6',variable=batonik)
        self.label13.grid(row=9, column=2)

        self.label14 = tk.Button(okno, text='Wyślij Formularz', background='#76FEC6', command=self.wyslij_formularz)
        self.label14.grid(row=10, column=0)

        self.label15 = tk.Label(okno, text='Twoje informacje', background='#76EEC6', font=('Arial', 15, 'italic'))
        self.label15.grid(row=11)

        self.label16 = tk.Label(okno, text='Imię: ', background='#76EEC6')
        self.label16.grid(row=12, column=0)
        self.wyswietl_imie = tk.Label(okno, text='', background='#76EEC6')
        self.wyswietl_imie.grid(row=12, column=1)

        self.label17 = tk.Label(okno, text='Nazwisko: ', background='#76EEC6')
        self.label17.grid(row=13, column=0)
        self.wyswietl_nazwisko = tk.Label(okno, text='', background='#76EEC6')
        self.wyswietl_nazwisko.grid(row=13, column=1)

        global zdjecie
        image = Image.open("facebook.png")
        zdjecie = ImageTk.PhotoImage(image)
        self.label18 = tk.Label(okno, image=zdjecie)
        self.label18.grid(row=14,column=0)


    def wyslij_formularz(self):
        imie = self.tekst1.get()
        nazwisko = self.tekst2.get()

        self.wyswietl_imie.config(text=imie)
        self.wyswietl_nazwisko.config(text=nazwisko)

    


okno = tk.Tk()
okno.title('Formularz')
okno.configure(background=('#76EEC6'))
okno.geometry('900x900')
okno.resizable(False, False)
app = Aplikacja(okno)
okno.mainloop()       